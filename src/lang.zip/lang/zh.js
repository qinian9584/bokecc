export default {
  route: {
    Classroom: '云课堂',
    language: '中文',
    upushFlowNode:'推流节点：',
    username:'请输入昵称',
    password:'请输入密码',
  }, 
}