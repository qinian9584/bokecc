export default {
  route: {
    Classroom: 'Cloud Classroom',
    language: 'English',
    upushFlowNode:'Push flow node:',
    username:'Please enter a username',
    password:'Please enter a password',
  }, 
}